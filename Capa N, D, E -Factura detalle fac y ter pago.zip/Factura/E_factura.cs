﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_factura
    {

        public int No_factura { get; set; }
        public string fecha { get; set; }

        public int cod_termino{ get; set; }
   
        public string id_cliente { get; set; }
        public int cod_empleado { get; set; }
    }
}
