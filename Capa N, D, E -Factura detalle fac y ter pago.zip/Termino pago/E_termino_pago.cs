﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_termino_pago
    {
        public int cod_termino { get; set; }

        public string descripcion { get; set; }
    }
}
