﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_detalle_factura
    {


        public int No_factura { get; set; }
        public string id_producto { get; set; }
        public string cantidad { get; set; }
        public string precio_venta { get; set; }
        public string precio_unitario { get; set; }
        public string importe { get; set; }
        public string ISV { get; set; }
        public string subtotal { get; set; }
        public string total { get; set; }
    }
}
